# NailConnect Kenya — Android APK builder

This project prepares an Android wrapper around the existing live NailConnect Kenya web app.

**Live web app:** https://nailconnect-kenya-wjm6k9.v2.appdeploy.ai/

## Important limitations

- This is an online wrapper, not a fully offline copy of the website.
- An internet connection is required to load the app.
- The app uses Android WebView storage, which is separate from Chrome's browser storage. Existing Chrome records will not automatically transfer.
- This workflow creates a **debug APK** for testing. It is not a signed release APK for Google Play.
- The APK has not been built or device-tested from this source bundle yet.

## Build an APK with GitHub Actions (no Android Studio required)

1. Download and unzip this project.
2. Sign in to GitHub and create a **new private repository** named `nailconnect-kenya-android`.
3. Upload all files and folders from this unzipped project to the repository. Make sure `.github/workflows/build-android-apk.yml` is included.
4. Open the repository's **Actions** tab.
5. Choose **Build NailConnect Kenya APK**, then click **Run workflow**. A push to the `main` branch also starts a build.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `NailConnect-Kenya-debug-APK`.
8. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
9. Transfer `app-debug.apk` to your Android phone and open it to install. Android may ask you to allow installs from that file app/browser. Only install APKs you built yourself or trust.

## If GitHub Actions fails

Open the failed workflow and copy the error message. Capacitor/Android Gradle versions may need adjustment as Android build tooling changes.

## Data and privacy

Client, booking, and money records currently stored in the web app are browser-local. Because the APK opens the live site in its own WebView, it has separate local storage. Do not uninstall the app or clear its storage before exporting/backing up records. This wrapper does not add cloud sync or user accounts.
