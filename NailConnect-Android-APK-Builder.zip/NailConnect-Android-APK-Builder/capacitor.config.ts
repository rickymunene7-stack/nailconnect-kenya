import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ke.co.nailconnect',
  appName: 'NailConnect Kenya',
  webDir: 'www',
  server: {
    url: 'https://nailconnect-kenya-wjm6k9.v2.appdeploy.ai/',
    cleartext: false,
    allowNavigation: ['nailconnect-kenya-wjm6k9.v2.appdeploy.ai']
  },
  android: {
    allowMixedContent: false
  }
};

export default config;
